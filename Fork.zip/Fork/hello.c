#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>		
#include<fcntl.h>
int main(int argc,char *argv[])
{
	printf("Inside new process:%d\n",getpid());
	printf("first argument:%s\n",argv[0]);
	printf("sec argument:%s\n",argv[1]);
	return 0;
}