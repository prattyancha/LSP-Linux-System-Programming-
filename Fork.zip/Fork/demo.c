#include<stdio.h>

int main()
{
	printf("Inside new process");
	return 0;
}