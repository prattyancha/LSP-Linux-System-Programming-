#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>		


//int i=10;	//part of DS section

int main()
{
	int *p=NULL;
	p=(int *)malloc(4);  //heap 
	*p=10;
	if(fork()==0)
	{
		++(*p);
		printf("%d\n",*p);
	}
	else
	{
		++(*p);
		printf("%d\n",*p);
	}						//child process gets created
	//printf("World\n");//for parent and child
	
	exit(0);
}

