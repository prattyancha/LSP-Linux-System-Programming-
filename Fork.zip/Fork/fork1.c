#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
//woest way to call fork with out if
//best war
int main()
{
	printf("Hello\n");// only for parent
	if(fork()==0)
	{
		printf("A\n");
	}
	else
	{
		printf("B\n");
	}						//child process gets created
	//printf("World\n");//for parent and child
	
	exit(0);
}

