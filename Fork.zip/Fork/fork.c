#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	int ret=0;
	
	//ret=fork();
	
	if((ret=fork())==0) 		//Child process is running
	{
		printf("Child process is running with PID: %d\n",getpid());
		printf("Parent of Child process: %d\n",getppid());
		printf("Child says: value of ret is: %d\n",ret);
	}
	else			//Parent process is running
	{
		printf("Parent process is running with PID: %d\n",getpid());
		printf("Parent of Parent processis (Terminal): %d\n",getppid());
		printf("Parent says: value of ret is: %d\n",ret);
	}
	exit(0);
}



/*
Parent process is running with PID: 3588
Child process is running with PID: 3589
Parent of Parent processis (Terminal): 9
Parent of Child process: 3588
Parent says: value of ret is: 3589
Child says: value of ret is: 0


*/