#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
//woest way to call fork with out if
//best war
int main()
{
	int i=10;//part of stack section
	//printf("Hello\n");// only for parent
	if(fork()==0)
	{
		i++;
		printf("%d\n",i);
	}
	else
	{
		i++;
		printf("%d\n",i);
	}						//child process gets created
	//printf("World\n");//for parent and child
	
	exit(0);
}

