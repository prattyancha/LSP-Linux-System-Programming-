#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>		
#include<fcntl.h>
/*
after system call child process gets the copy of parents text data stack heap and all child gets access to all
the files which are opened by the parents .
*/


int main()
{
	int fd=0;
	fd=open("Demo.txt",O_WRONLY); //opened by parent process
	if(fork()==0)		//Child
	{
		write(fd,"child",5);
	}
	else				//parent
	{
		write(fd,"parent",6);
	}						
	
	exit(0);
}

