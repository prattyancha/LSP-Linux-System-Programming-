#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>		
#include<fcntl.h>
/*
execl is used to replace text data stack of existing child process with text data 
stack of new process.
execl
execl-list og args
exece
execv-vector or array
execp
*/


int main()
{
	
	if(fork()==0)		//Child
	{
	//         myexe    comd args  environment variable  
		execl("./helloexe","python","golang",NULL);	//new process
	}
	else				//parent
	{
		printf("\nparent process running PID :%d\n",getpid());
	}						
	
	exit(0);
}

