#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void fun()		//part of text section
{
	int i=10;	//part of stack section
	i++;
	
	printf("%d\n",i);
}
int main()
{
	int i=10;//part of stack section
	//printf("Hello\n");// only for parent
	if(fork()==0)
	{
		fun();
	}
	else
	{
		fun();
	}						//child process gets created
	//printf("World\n");//for parent and child
	
	exit(0);
}

